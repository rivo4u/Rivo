# Rivo Flutter UI + Supabase

Rivo voice-social app UI layer with Supabase Auth/Database integration started.

## Current integration
- Supabase project URL configured with the client-side publishable key.
- Google-only authentication scaffolded with `google_sign_in` + Supabase `signInWithIdToken`.
- Auth gate routes signed-in users to the existing Home UI and signed-out users to Google login.
- Rivo API service added for profiles, rooms, room membership, mic seats and realtime room chat.
- Existing Room Tools and Game sheets are preserved.

## Google Android setup still required
The native Android Google Sign-In flow needs an Android OAuth client in Google Cloud with the app package name and SHA-1 certificate. The existing web OAuth client is configured as Supabase's server client ID.

## Supabase security
The database already uses RLS and protected RPC functions. Do not put a service-role/secret key in this Flutter project.
