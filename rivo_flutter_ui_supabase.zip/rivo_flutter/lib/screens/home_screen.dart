import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../widgets/common.dart';
import 'voice_room_screen.dart';

class RoomSummary {
  final String badge; // e.g. SVIP1 / SVIP2
  final String hostInitial;
  final String title;
  final String tagline;
  final int liveCount;

  const RoomSummary({
    required this.badge,
    required this.hostInitial,
    required this.title,
    required this.tagline,
    required this.liveCount,
  });
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int topTab = 0; // 0 = Mine, 1 = Hot

  final rooms = const [
    RoomSummary(badge: 'SVIP2', hostInitial: 'V', title: 'Voice ki Duniya…', tagline: 'Abhi to party shuro hoi…', liveCount: 82),
    RoomSummary(badge: 'SVIP1', hostInitial: 'A', title: 'Ashiyana Meri Mohabbat Ka', tagline: 'Ashiyana meri mohabbat ka', liveCount: 22),
    RoomSummary(badge: 'SVIP2', hostInitial: 'P', title: 'Peshawar Gulona', tagline: 'Apni nazar or dil hamesha saf…', liveCount: 68),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _topNav(),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.only(bottom: 12),
                children: [
                  _featureRow(),
                  const SizedBox(height: 4),
                  ...rooms.map(_roomCard),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: RivoBottomNav(currentIndex: 0, onTap: (_) {}),
    );
  }

  Widget _topNav() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
      child: Row(
        children: [
          _navTab('Mine', 0),
          const SizedBox(width: 22),
          _navTab('Hot', 1),
          const Spacer(),
          const Icon(Icons.search_rounded, color: AppColors.greenDark),
          const SizedBox(width: 14),
          const Icon(Icons.notifications_none_rounded, color: AppColors.greenDark),
        ],
      ),
    );
  }

  Widget _navTab(String label, int index) {
    final active = topTab == index;
    return InkWell(
      onTap: () => setState(() => topTab = index),
      child: Text(
        label,
        style: AppTextStyles.heading(
          size: 18,
          color: active ? AppColors.greenDark : AppColors.textMute,
        ),
      ),
    );
  }

  Widget _featureRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(child: _featureCard('Pak Official Room', 263, Icons.pets_rounded)),
          const SizedBox(width: 10),
          Expanded(child: _featureCard('Mehar Di Adaa', 154, Icons.groups_rounded)),
        ],
      ),
    );
  }

  Widget _featureCard(String title, int fire, IconData icon) {
    return AspectRatio(
      aspectRatio: 0.9,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.greenLight, AppColors.greenMid],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: AppColors.green, width: 2),
          borderRadius: BorderRadius.circular(AppRadius.lg),
        ),
        child: Stack(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.85),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text('🔥 $fire', style: AppTextStyles.label(size: 11, color: const Color(0xFFE0663A))),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Icon(icon, size: 40, color: AppColors.greenDark.withOpacity(0.6)),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Text(title,
                  style: AppTextStyles.label(size: 12, color: AppColors.greenDarker)
                      .copyWith(fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _roomCard(RoomSummary room) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const VoiceRoomScreen()),
        ),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.greenLight,
            border: Border.all(color: AppColors.green, width: 1.4),
            borderRadius: BorderRadius.circular(AppRadius.lg),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppAvatar(label: room.hostInitial, size: 48),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.greenDark,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(room.badge,
                          style: AppTextStyles.label(size: 10, color: Colors.white)
                              .copyWith(fontWeight: FontWeight.w800)),
                    ),
                    const SizedBox(height: 4),
                    Text(room.title,
                        style: AppTextStyles.heading(size: 14, color: AppColors.greenDarker)),
                    const SizedBox(height: 6),
                    Text(room.tagline, style: AppTextStyles.label(size: 11.5)),
                  ],
                ),
              ),
              Text('🔥 ${room.liveCount}',
                  style: AppTextStyles.label(size: 11, color: const Color(0xFFE0663A))
                      .copyWith(fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      ),
    );
  }
}
