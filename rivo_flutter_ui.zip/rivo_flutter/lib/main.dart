import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';

// TODO: move these into a secure config (--dart-define or a .env loader)
// before shipping. Never commit real keys to source control.
const supabaseUrl = 'https://YOUR_PROJECT.supabase.co';
const supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const RivoApp());
}

class RivoApp extends StatelessWidget {
  const RivoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rivo',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const RootShell(),
    );
  }
}

/// Bottom-tab shell: Room / Moment / Message / Me.
/// Auth (splash/login/register) sits in front of this once wired up —
/// this file only owns the post-login shell for the screens built so far.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeScreen(),
      const _PlaceholderTab(label: 'Moment'),
      const _PlaceholderTab(label: 'Message'),
      const ProfileScreen(),
    ];
    return pages[index];
  }
}

/// Placeholder for tabs not yet designed (Moment, Message feeds).
class _PlaceholderTab extends StatelessWidget {
  final String label;
  const _PlaceholderTab({required this.label});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('$label — coming next')),
    );
  }
}
