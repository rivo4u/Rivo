import 'package:supabase_flutter/supabase_flutter.dart';

class RivoApi {
  RivoApi(this.client);

  final SupabaseClient client;

  Future<Map<String, dynamic>?> myProfile() async {
    final user = client.auth.currentUser;
    if (user == null) return null;
    return await client.from('profiles').select().eq('id', user.id).maybeSingle();
  }

  Future<List<Map<String, dynamic>>> activeRooms() async {
    final rows = await client
        .from('rooms')
        .select('id, owner_id, title, description, is_active, created_at')
        .eq('is_active', true)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> joinRoom(String roomId) async {
    await client.rpc('join_room', params: {'p_room_id': roomId});
  }

  Future<void> leaveRoom(String roomId) async {
    await client.rpc('leave_room', params: {'p_room_id': roomId});
  }

  Future<List<Map<String, dynamic>>> roomSeats(String roomId) async {
    final rows = await client
        .from('mic_seats')
        .select('seat_no, user_id, is_muted, updated_at')
        .eq('room_id', roomId)
        .order('seat_no');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> roomMessages(String roomId) async {
    final rows = await client
        .from('room_messages')
        .select('id, user_id, body, created_at')
        .eq('room_id', roomId)
        .order('created_at', ascending: true)
        .limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> sendRoomMessage(String roomId, String body) async {
    await client.rpc('send_room_message', params: {
      'p_room_id': roomId,
      'p_body': body,
    });
  }

  Stream<List<Map<String, dynamic>>> watchRoomMessages(String roomId) {
    return client
        .from('room_messages')
        .stream(primaryKey: ['id'])
        .eq('room_id', roomId)
        .order('created_at', ascending: true);
  }

  Stream<List<Map<String, dynamic>>> watchSeats(String roomId) {
    return client
        .from('mic_seats')
        .stream(primaryKey: ['room_id', 'seat_no'])
        .eq('room_id', roomId)
        .order('seat_no');
  }

  Future<void> claimSeat(String roomId, int seatNo) async {
    await client.rpc('claim_mic_seat', params: {
      'p_room_id': roomId,
      'p_seat_no': seatNo,
    });
  }

  Future<void> releaseSeat(String roomId, int seatNo) async {
    await client.rpc('release_mic_seat', params: {
      'p_room_id': roomId,
      'p_seat_no': seatNo,
    });
  }

  Future<void> setSeatMute(String roomId, int seatNo, bool muted) async {
    await client.rpc('set_mic_mute', params: {
      'p_room_id': roomId,
      'p_seat_no': seatNo,
      'p_muted': muted,
    });
  }
}
