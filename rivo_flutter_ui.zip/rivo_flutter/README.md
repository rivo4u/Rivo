# Rivo — Flutter UI (Phase 1)

Ye 6 screens ka real Flutter code hai, jo humne HTML preview mein design kiya tha.
Same light-green + white theme (`lib/theme/app_colors.dart`) — poori app mein yahi tokens use karna hai
taake har screen ek hi product ki tarah lage.

## Is drop mein kya hai
- `lib/theme/` — colors, text styles, ThemeData (Manrope headings + Inter body via `google_fonts`)
- `lib/widgets/common.dart` — AppAvatar, SectionCard, StatColumn, GridIconItem, RivoBottomNav
- `lib/screens/profile_screen.dart` — Me tab
- `lib/screens/public_profile_screen.dart` — dusray user ki profile
- `lib/screens/home_screen.dart` — Room list (Mine/Hot)
- `lib/screens/voice_room_screen.dart` — 10-seat voice room + chat
- `lib/widgets/game_sheet.dart`, `lib/widgets/room_tools_sheet.dart` — room ke andar bottom sheets
- `lib/main.dart` — app entry + bottom-tab shell + Supabase init placeholder

## Setup
1. Ye folder apne Flutter project ke `lib/` ke sath merge karein (ya isi ko project root banayein).
2. `pubspec.yaml` mein dependencies already listed hain — run:
   ```
   flutter pub get
   ```
3. `lib/main.dart` mein `supabaseUrl` aur `supabaseAnonKey` apni Supabase project ki values se replace karein
   (production mein `--dart-define` ya `.env` use karein, keys ko source mein hardcode na karein).
4. Run:
   ```
   flutter run
   ```

## Abhi kya mock hai
- Room list, chat messages, medals — sab static/mock data hai (`home_screen.dart`, `public_profile_screen.dart`).
- Supabase client initialize ho raha hai, lekin koi query abhi wire nahi hui — agla phase iska hoga.
- Voice/mic seats UI hi hai; Vivox/LiveKit integration is phase mein nahi hai.

## Agla phase (jab bolein)
Scope document ke hisaab se baqi modules is tarteeb mein banenge:
1. Auth flow (Splash → Login → Register → Country select)
2. Gifts / Coins / Wallet
3. Host / Agency / BD dashboards
4. Admin / Super Admin
5. Supabase schema + real data wiring
