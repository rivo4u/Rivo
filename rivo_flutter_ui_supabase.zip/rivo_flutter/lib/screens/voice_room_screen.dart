import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../widgets/common.dart';
import '../widgets/game_sheet.dart';
import '../widgets/room_tools_sheet.dart';

class VoiceRoomScreen extends StatelessWidget {
  final String hostName;
  final String hostId;
  final int trophyCount;
  final int onlineCount;

  const VoiceRoomScreen({
    super.key,
    this.hostName = 'Mr Adi',
    this.hostId = '192681',
    this.trophyCount = 10800,
    this.onlineCount = 1,
  });

  void _openSheet(BuildContext context, Widget sheet) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => sheet,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.roomDeep,
      body: SafeArea(
        child: Column(
          children: [
            _header(context),
            _seatsGrid(),
            Expanded(child: _chatArea()),
            _inputBar(context),
          ],
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF243027), AppColors.roomDeep],
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      AppAvatar(label: hostName, size: 26, ringColor: Colors.transparent),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(hostName,
                              style: AppTextStyles.body(
                                  size: 12.5, weight: FontWeight.w800, color: AppColors.roomText)),
                          Text('ID: $hostId',
                              style: AppTextStyles.label(size: 10, color: AppColors.roomTextMute)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              _roomIcon(Icons.ios_share_rounded),
              const SizedBox(width: 8),
              _roomIcon(Icons.groups_rounded),
              const SizedBox(width: 8),
              _roomIcon(Icons.power_settings_new_rounded, onTap: () => Navigator.maybePop(context)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.emoji_events_rounded, size: 16, color: Colors.amber.shade300),
              const SizedBox(width: 6),
              Text('${(trophyCount / 1000).toStringAsFixed(1)}K',
                  style: AppTextStyles.body(size: 13, weight: FontWeight.w800, color: AppColors.roomText)),
              const Icon(Icons.chevron_right_rounded, size: 16, color: AppColors.roomTextMute),
              const Spacer(),
              CircleAvatar(radius: 10, backgroundColor: AppColors.green),
              const SizedBox(width: 6),
              Text('$onlineCount', style: AppTextStyles.label(size: 11, color: AppColors.roomTextMute)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _roomIcon(IconData icon, {VoidCallback? onTap}) {
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), shape: BoxShape.circle),
        alignment: Alignment.center,
        child: Icon(icon, size: 14, color: AppColors.roomText),
      ),
    );
  }

  Widget _seatsGrid() {
    return Container(
      color: AppColors.roomDeep,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
      child: GridView.count(
        crossAxisCount: 5,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 10,
        mainAxisSpacing: 14,
        childAspectRatio: 0.78,
        children: List.generate(10, (i) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.green, width: 2),
                  color: AppColors.green.withOpacity(0.15),
                ),
                alignment: Alignment.center,
                child: Icon(Icons.mic_none_rounded, color: AppColors.green, size: 18),
              ),
              const SizedBox(height: 4),
              Text('No.${i + 1}', style: AppTextStyles.label(size: 9.5, color: AppColors.roomTextMute)),
            ],
          );
        }),
      ),
    );
  }

  Widget _chatArea() {
    return Container(
      width: double.infinity,
      color: AppColors.roomDeep,
      padding: const EdgeInsets.fromLTRB(16, 10, 60, 10),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _chatBubble("Welcome everyone! Let's chat and have fun together."),
              const SizedBox(height: 8),
              _chatBubble('Welcome Victor into the room', highlightName: 'Victor'),
            ],
          ),
          Positioned(
            right: -44,
            top: 4,
            child: Container(
              width: 38,
              height: 38,
              decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.green),
              alignment: Alignment.center,
              child: const Icon(Icons.diamond_rounded, size: 18, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chatBubble(String text, {String? highlightName}) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 260),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(10),
      ),
      child: RichText(
        text: TextSpan(
          style: AppTextStyles.body(size: 12, color: AppColors.roomTextMute),
          children: highlightName == null
              ? [TextSpan(text: text)]
              : [
                  const TextSpan(text: 'Welcome '),
                  TextSpan(
                      text: highlightName,
                      style: AppTextStyles.body(size: 12, weight: FontWeight.w800, color: AppColors.green)),
                  const TextSpan(text: ' into the room'),
                ],
        ),
      ),
    );
  }

  Widget _inputBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: const BoxDecoration(
        color: AppColors.roomDeep,
        border: Border(top: BorderSide(color: Color(0x14FFFFFF))),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text('Say something',
                  style: AppTextStyles.body(size: 12, color: AppColors.roomTextMute)),
            ),
          ),
          const SizedBox(width: 8),
          _inputIcon(Icons.emoji_emotions_outlined),
          _inputIcon(Icons.mic_none_rounded),
          _inputIcon(Icons.card_giftcard_rounded),
          _inputIcon(Icons.videogame_asset_rounded, onTap: () => _openSheet(context, const GameSheet())),
          _inputIcon(Icons.grid_view_rounded, onTap: () => _openSheet(context, const RoomToolsSheet())),
        ],
      ),
    );
  }

  Widget _inputIcon(IconData icon, {VoidCallback? onTap}) {
    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), shape: BoxShape.circle),
          alignment: Alignment.center,
          child: Icon(icon, size: 15, color: AppColors.roomText),
        ),
      ),
    );
  }
}
