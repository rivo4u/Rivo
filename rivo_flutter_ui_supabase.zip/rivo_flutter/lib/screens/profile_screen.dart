import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../widgets/common.dart';

class ProfileScreen extends StatelessWidget {
  final String username;
  final String userId;
  final int visitors;
  final int following;
  final int followers;

  const ProfileScreen({
    super.key,
    this.username = 'Victor',
    this.userId = '192681',
    this.visitors = 3,
    this.following = 1,
    this.followers = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _header(),
              _vipRow(),
              SectionCard(
                child: GridView.count(
                  crossAxisCount: 4,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: const [
                    GridIconItem(icon: Icons.account_balance_wallet_rounded, label: 'Wallet'),
                    GridIconItem(icon: Icons.diamond_rounded, label: 'Diamond'),
                    GridIconItem(icon: Icons.storefront_rounded, label: 'Store'),
                    GridIconItem(icon: Icons.shopping_bag_rounded, label: 'Bag'),
                  ],
                ),
              ),
              SectionCard(
                child: GridView.count(
                  crossAxisCount: 4,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  childAspectRatio: 0.85,
                  children: const [
                    GridIconItem(icon: Icons.badge_rounded, label: 'Host Center'),
                    GridIconItem(icon: Icons.workspace_premium_rounded, label: 'BD Center'),
                    GridIconItem(icon: Icons.favorite_rounded, label: 'CP'),
                    GridIconItem(icon: Icons.groups_rounded, label: 'Brother & Sister'),
                    GridIconItem(icon: Icons.flag_rounded, label: 'Family'),
                    GridIconItem(icon: Icons.emoji_events_rounded, label: 'Level'),
                    GridIconItem(icon: Icons.handshake_rounded, label: 'Close Friends'),
                    GridIconItem(icon: Icons.headset_mic_rounded, label: 'Contact us'),
                    GridIconItem(icon: Icons.settings_rounded, label: 'Setting'),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
      bottomNavigationBar: RivoBottomNav(currentIndex: 3, onTap: (_) {}),
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 22),
      decoration: const BoxDecoration(gradient: AppColors.gradientHeader),
      child: Column(
        children: [
          Row(
            children: [
              const AppAvatar(label: 'Victor', size: 70),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(username, style: AppTextStyles.heading(size: 21)),
                        const SizedBox(width: 6),
                        const Icon(Icons.male_rounded, size: 18, color: AppColors.green),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text('ID: $userId', style: AppTextStyles.label()),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: AppColors.textMute),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              StatColumn(value: '$visitors', label: 'Visitors'),
              StatColumn(value: '$following', label: 'Following'),
              StatColumn(value: '$followers', label: 'Followers'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _vipRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 4),
      child: Row(
        children: [
          Expanded(child: _vipCard('VIP', Icons.favorite_rounded, AppColors.gradientVip)),
          const SizedBox(width: 10),
          Expanded(child: _vipCard('SVIP', Icons.diamond_rounded, AppColors.gradientSvip)),
        ],
      ),
    );
  }

  Widget _vipCard(String label, IconData icon, Gradient gradient) {
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(gradient: gradient, borderRadius: BorderRadius.circular(14)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: AppTextStyles.heading(size: 19, color: Colors.white).copyWith(letterSpacing: 1)),
          CircleAvatar(
            radius: 15,
            backgroundColor: Colors.white.withOpacity(0.25),
            child: Icon(icon, size: 14, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
