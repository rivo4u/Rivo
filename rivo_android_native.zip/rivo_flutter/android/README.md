# Rivo Android Native Setup

Package/Application ID: `com.rivo.app`

Included:
- Android Gradle project
- AndroidX
- Internet permission
- Microphone permission for voice rooms
- Rivo OAuth deep-link scheme: `rivo://login-callback`

Supabase OAuth:
Configure the matching redirect URL in the Flutter Supabase Auth flow and in the Supabase Auth URL configuration.

Google Sign-In:
Use the Google OAuth client already configured in Supabase. Android SHA-1/SHA-256 fingerprints still need to be generated from the final signing keystore before production Google OAuth verification.
